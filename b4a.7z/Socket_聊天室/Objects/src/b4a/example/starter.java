package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class starter extends  android.app.Service{
	public static class starter_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (starter) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, starter.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, true, BA.class);
		}

	}
    static starter mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return starter.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "b4a.example", "b4a.example.starter");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "b4a.example.starter", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!true && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (starter) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (true) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (starter) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (true)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (starter) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (true) {
            BA.LogInfo("** Service (starter) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (starter) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static boolean _connected = false;
public static anywheresoftware.b4a.objects.SocketWrapper _client = null;
public static anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public static anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public static int _port = 0;
public static boolean _working = false;
public b4a.example.main _main = null;
public static boolean  _application_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
 //BA.debugLineNum = 52;BA.debugLine="Return True";
if (true) return anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return false;
}
public static String  _astream_error() throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Sub AStream_Error";
 //BA.debugLineNum = 96;BA.debugLine="UpdateState(False)	'UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public static String  _astream_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 105;BA.debugLine="Sub AStream_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 106;BA.debugLine="CallSub2(Main, \"NewData\", Buffer)";
anywheresoftware.b4a.keywords.Common.CallSubNew2(processBA,(Object)(mostCurrent._main.getObject()),"NewData",(Object)(_buffer));
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public static String  _astream_terminated() throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Sub AStream_Terminated";
 //BA.debugLineNum = 101;BA.debugLine="UpdateState(False)	'UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public static String  _closeexistingconnection() throws Exception{
 //BA.debugLineNum = 82;BA.debugLine="Sub CloseExistingConnection";
 //BA.debugLineNum = 83;BA.debugLine="If astream.IsInitialized Then astream.Close";
if (_astream.IsInitialized()) { 
_astream.Close();};
 //BA.debugLineNum = 84;BA.debugLine="If client.IsInitialized Then client.Close";
if (_client.IsInitialized()) { 
_client.Close();};
 //BA.debugLineNum = 85;BA.debugLine="UpdateState (False)	'UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return "";
}
public static void  _connecttoserver(String _host) throws Exception{
ResumableSub_ConnectToServer rsub = new ResumableSub_ConnectToServer(null,_host);
rsub.resume(processBA, null);
}
public static class ResumableSub_ConnectToServer extends BA.ResumableSub {
public ResumableSub_ConnectToServer(b4a.example.starter parent,String _host) {
this.parent = parent;
this._host = _host;
}
b4a.example.starter parent;
String _host;
boolean _successful = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 61;BA.debugLine="Log(\"嘗試連線到: \" & Host)";
anywheresoftware.b4a.keywords.Common.LogImpl("11048577","嘗試連線到: "+_host,0);
 //BA.debugLineNum = 62;BA.debugLine="CloseExistingConnection";
_closeexistingconnection();
 //BA.debugLineNum = 63;BA.debugLine="Dim client As Socket";
parent._client = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 64;BA.debugLine="client.Initialize(\"client\")";
parent._client.Initialize("client");
 //BA.debugLineNum = 65;BA.debugLine="client.Connect(Host, PORT, 10000)";
parent._client.Connect(processBA,_host,parent._port,(int) (10000));
 //BA.debugLineNum = 67;BA.debugLine="Wait For Client_Connected (Successful As Boolean)";
anywheresoftware.b4a.keywords.Common.WaitFor("client_connected", processBA, this, null);
this.state = 7;
return;
case 7:
//C
this.state = 1;
_successful = (Boolean) result[0];
;
 //BA.debugLineNum = 68;BA.debugLine="If Successful Then";
if (true) break;

case 1:
//if
this.state = 6;
if (_successful) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 70;BA.debugLine="astream.InitializePrefix(client.InputStream, Fal";
parent._astream.InitializePrefix(processBA,parent._client.getInputStream(),anywheresoftware.b4a.keywords.Common.False,parent._client.getOutputStream(),"astream");
 //BA.debugLineNum = 71;BA.debugLine="UpdateState (True)		'成功的話.UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.True);
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 73;BA.debugLine="ToastMessageShow(\"連線失敗: \" & LastException, True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("連線失敗: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA))),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 74;BA.debugLine="Log(\"連線失敗: \" & LastException)";
anywheresoftware.b4a.keywords.Common.LogImpl("11048590","連線失敗: "+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(processBA)),0);
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _client_connected(boolean _successful) throws Exception{
}
public static String  _disconnect() throws Exception{
 //BA.debugLineNum = 78;BA.debugLine="Public Sub Disconnect";
 //BA.debugLineNum = 79;BA.debugLine="CloseExistingConnection";
_closeexistingconnection();
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public static void  _listenforconnections() throws Exception{
ResumableSub_ListenForConnections rsub = new ResumableSub_ListenForConnections(null);
rsub.resume(processBA, null);
}
public static class ResumableSub_ListenForConnections extends BA.ResumableSub {
public ResumableSub_ListenForConnections(b4a.example.starter parent) {
this.parent = parent;
}
b4a.example.starter parent;
boolean _successful = false;
anywheresoftware.b4a.objects.SocketWrapper _newsocket = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 27;BA.debugLine="Do While working";
if (true) break;

case 1:
//do while
this.state = 8;
while (parent._working) {
this.state = 3;
if (true) break;
}
if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 28;BA.debugLine="server.Listen";
parent._server.Listen();
 //BA.debugLineNum = 29;BA.debugLine="Wait For Server_NewConnection (Successful As Boo";
anywheresoftware.b4a.keywords.Common.WaitFor("server_newconnection", processBA, this, null);
this.state = 9;
return;
case 9:
//C
this.state = 4;
_successful = (Boolean) result[0];
_newsocket = (anywheresoftware.b4a.objects.SocketWrapper) result[1];
;
 //BA.debugLineNum = 30;BA.debugLine="If Successful Then";
if (true) break;

case 4:
//if
this.state = 7;
if (_successful) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 31;BA.debugLine="CloseExistingConnection		'先關閉 astream/client.避免";
_closeexistingconnection();
 //BA.debugLineNum = 32;BA.debugLine="client = NewSocket";
parent._client = _newsocket;
 //BA.debugLineNum = 35;BA.debugLine="astream.InitializePrefix(client.InputStream, Fa";
parent._astream.InitializePrefix(processBA,parent._client.getInputStream(),anywheresoftware.b4a.keywords.Common.False,parent._client.getOutputStream(),"astream");
 //BA.debugLineNum = 36;BA.debugLine="UpdateState(True)		'成功的話.UI介面 更新狀態";
_updatestate(anywheresoftware.b4a.keywords.Common.True);
 if (true) break;

case 7:
//C
this.state = 1;
;
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static void  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Public connected As Boolean			'連線狀態.True連線中.False";
_connected = false;
 //BA.debugLineNum = 10;BA.debugLine="Private client As Socket			'Network lib.客戶端 socke";
_client = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Public server As ServerSocket		'Network lib.服務器端";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private astream As AsyncStreams		'RandomAccessFil";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 14;BA.debugLine="Private const PORT As Int = 51042	'連線的port";
_port = (int) (51042);
 //BA.debugLineNum = 15;BA.debugLine="Private working As Boolean = True";
_working = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public static String  _senddata(byte[] _data) throws Exception{
 //BA.debugLineNum = 110;BA.debugLine="Public Sub SendData (data() As Byte)";
 //BA.debugLineNum = 112;BA.debugLine="If connected Then astream.Write(data)";
if (_connected) { 
_astream.Write(_data);};
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 21;BA.debugLine="server.Initialize(PORT, \"server\")		'server物件 初始化";
_server.Initialize(processBA,_port,"server");
 //BA.debugLineNum = 22;BA.debugLine="ListenForConnections					'server正在聆聽";
_listenforconnections();
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public static String  _service_taskremoved() throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub Service_TaskRemoved";
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public static String  _updatestate(boolean _newstate) throws Exception{
 //BA.debugLineNum = 89;BA.debugLine="Sub UpdateState (NewState As Boolean)";
 //BA.debugLineNum = 90;BA.debugLine="connected = NewState";
_connected = _newstate;
 //BA.debugLineNum = 91;BA.debugLine="CallSub(Main, \"SetState\")";
anywheresoftware.b4a.keywords.Common.CallSubNew(processBA,(Object)(mostCurrent._main.getObject()),"SetState");
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
}
