package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btn_connect = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btn_send = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lbl_myip = null;
public static anywheresoftware.b4j.objects.LabelWrapper _lbl_status = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txt_ip = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper _txt_msg = null;
public static anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper _txt_log = null;
public static b4j.example.class_socket _socket1 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 24;BA.debugLine="socket1.Initialize(51042)";
_socket1._initialize /*String*/ (ba,(int) (51042));
 //BA.debugLineNum = 26;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 27;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 28;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 30;BA.debugLine="SetState";
_setstate();
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public static String  _btn_connect_click() throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Private Sub btn_Connect_Click";
 //BA.debugLineNum = 38;BA.debugLine="If socket1.connected = False Then";
if (_socket1._connected /*boolean*/ ==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 39;BA.debugLine="If txt_IP.Text.Length = 0 Then";
if (_txt_ip.getText().length()==0) { 
 //BA.debugLineNum = 41;BA.debugLine="xui.MsgboxAsync(\"請輸入被連線端的IP.\", \"B4X\")";
_xui.MsgboxAsync(ba,"請輸入被連線端的IP.","B4X");
 //BA.debugLineNum = 42;BA.debugLine="Return";
if (true) return "";
 }else {
 //BA.debugLineNum = 45;BA.debugLine="socket1.ConnectToServer(txt_IP.text)";
_socket1._connecttoserver /*void*/ (_txt_ip.getText());
 };
 }else {
 //BA.debugLineNum = 49;BA.debugLine="socket1.Disconnect";
_socket1._disconnect /*String*/ ();
 };
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public static String  _btn_send_click() throws Exception{
String _instring = "";
byte[] _stringbytes = null;
String _d1 = "";
 //BA.debugLineNum = 54;BA.debugLine="Private Sub btn_Send_Click";
 //BA.debugLineNum = 55;BA.debugLine="Dim InString          As String =txt_Msg.Text";
_instring = _txt_msg.getText();
 //BA.debugLineNum = 56;BA.debugLine="Dim StringBytes() As Byte = InString.GetBytes(\"UT";
_stringbytes = _instring.getBytes("UTF8");
 //BA.debugLineNum = 58;BA.debugLine="Dim d1 As String";
_d1 = "";
 //BA.debugLineNum = 60;BA.debugLine="DateTime.DateFormat = \"yyyy/MM/dd\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("yyyy/MM/dd");
 //BA.debugLineNum = 61;BA.debugLine="d1 = DateTime.Date(DateTime.Now)";
_d1 = anywheresoftware.b4a.keywords.Common.DateTime.Date(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 62;BA.debugLine="DateTime.TimeFormat=\"hh:mm a\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("hh:mm a");
 //BA.debugLineNum = 63;BA.debugLine="d1=d1& \" \" & DateTime.Time(DateTime.Now)";
_d1 = _d1+" "+anywheresoftware.b4a.keywords.Common.DateTime.Time(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 66;BA.debugLine="txt_Log.Text = d1 & \" Me: \" & InString     & CRLF";
_txt_log.setText(_d1+" Me: "+_instring+anywheresoftware.b4a.keywords.Common.CRLF+_txt_log.getText());
 //BA.debugLineNum = 69;BA.debugLine="socket1.SendData(StringBytes)";
_socket1._senddata /*String*/ (_stringbytes);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 34;BA.debugLine="xui.MsgboxAsync(\"Hello World!\", \"B4X\")";
_xui.MsgboxAsync(ba,"Hello World!","B4X");
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public static String  _newdata(byte[] _buffer) throws Exception{
String _instring = "";
String _d1 = "";
 //BA.debugLineNum = 91;BA.debugLine="Sub NewData (Buffer() As Byte)";
 //BA.debugLineNum = 92;BA.debugLine="Dim InString  As String =BytesToString(Buffer, 0,";
_instring = anywheresoftware.b4a.keywords.Common.BytesToString(_buffer,(int) (0),_buffer.length,"UTF-8");
 //BA.debugLineNum = 93;BA.debugLine="Dim d1 As String";
_d1 = "";
 //BA.debugLineNum = 95;BA.debugLine="DateTime.DateFormat = \"yyyy/MM/dd\"";
anywheresoftware.b4a.keywords.Common.DateTime.setDateFormat("yyyy/MM/dd");
 //BA.debugLineNum = 96;BA.debugLine="d1 = DateTime.Date(DateTime.Now)";
_d1 = anywheresoftware.b4a.keywords.Common.DateTime.Date(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 97;BA.debugLine="DateTime.TimeFormat=\"hh:mm a\"";
anywheresoftware.b4a.keywords.Common.DateTime.setTimeFormat("hh:mm a");
 //BA.debugLineNum = 98;BA.debugLine="d1=d1& \" \" & DateTime.Time(DateTime.Now)";
_d1 = _d1+" "+anywheresoftware.b4a.keywords.Common.DateTime.Time(anywheresoftware.b4a.keywords.Common.DateTime.getNow());
 //BA.debugLineNum = 100;BA.debugLine="txt_Log.Text = d1 & \" You: \" & InString   & CRLF";
_txt_log.setText(_d1+" You: "+_instring+anywheresoftware.b4a.keywords.Common.CRLF+_txt_log.getText());
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 7;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 8;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 9;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 11;BA.debugLine="Private btn_Connect As Button";
_btn_connect = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private btn_Send As Button";
_btn_send = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private lbl_MyIP As Label";
_lbl_myip = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private lbl_Status As Label";
_lbl_status = new anywheresoftware.b4j.objects.LabelWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private txt_IP As TextField";
_txt_ip = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private txt_Msg As TextField";
_txt_msg = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextFieldWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private txt_Log As TextArea";
_txt_log = new anywheresoftware.b4j.objects.TextInputControlWrapper.TextAreaWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private socket1 As class_socket";
_socket1 = new b4j.example.class_socket();
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public static String  _setstate() throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Sub SetState";
 //BA.debugLineNum = 77;BA.debugLine="btn_Send.Enabled = socket1.connected";
_btn_send.setEnabled(_socket1._connected /*boolean*/ );
 //BA.debugLineNum = 78;BA.debugLine="If socket1.connected Then";
if (_socket1._connected /*boolean*/ ) { 
 //BA.debugLineNum = 79;BA.debugLine="btn_Connect.Text = \"Disconnect\"";
_btn_connect.setText("Disconnect");
 //BA.debugLineNum = 80;BA.debugLine="lbl_Status.Text = \"連線中\"";
_lbl_status.setText("連線中");
 }else {
 //BA.debugLineNum = 82;BA.debugLine="btn_Connect.Text = \"Connect\"";
_btn_connect.setText("Connect");
 //BA.debugLineNum = 83;BA.debugLine="lbl_Status.Text = \"斷線\"";
_lbl_status.setText("斷線");
 };
 //BA.debugLineNum = 85;BA.debugLine="lbl_MyIP.Text =  socket1.server.GetMyIP";
_lbl_myip.setText(_socket1._server /*anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper*/ .GetMyIP());
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
}
