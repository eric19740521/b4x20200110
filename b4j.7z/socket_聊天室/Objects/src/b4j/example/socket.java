package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class socket extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.socket", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.socket.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.objects.JFX _fx = null;
public boolean _connected = false;
public anywheresoftware.b4a.objects.SocketWrapper _client = null;
public anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astream = null;
public boolean _working = false;
public b4j.example.main _main = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="Public connected As Boolean			'連線狀態.True連線中.False";
_connected = false;
 //BA.debugLineNum = 5;BA.debugLine="Private client As socket			'jNetwork lib.客戶端 sock";
_client = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 6;BA.debugLine="Public server As ServerSocket		'jNetwork lib.服務器端";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 7;BA.debugLine="Private astream As AsyncStreams		'jRandomAccessFi";
_astream = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 10;BA.debugLine="Private working As Boolean = True";
_working = __c.True;
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _closeexistingconnection() throws Exception{
 //BA.debugLineNum = 41;BA.debugLine="Sub CloseExistingConnection";
 //BA.debugLineNum = 42;BA.debugLine="If astream.IsInitialized Then astream.Close";
if (_astream.IsInitialized()) { 
_astream.Close();};
 //BA.debugLineNum = 43;BA.debugLine="If client.IsInitialized Then client.Close";
if (_client.IsInitialized()) { 
_client.Close();};
 //BA.debugLineNum = 44;BA.debugLine="UpdateState (False)	'UI介面 更新狀態";
_updatestate(__c.False);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _getip() throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="public Sub GetIP As String";
 //BA.debugLineNum = 59;BA.debugLine="Return server.GetMyIP";
if (true) return _server.GetMyIP();
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,int _port1) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize(port1 As Int)";
 //BA.debugLineNum = 18;BA.debugLine="server.Initialize(port1, \"server\")		'server物件 初始化";
_server.Initialize(ba,_port1,"server");
 //BA.debugLineNum = 19;BA.debugLine="ListenForConnections					'server正在聆聽";
_listenforconnections();
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public void  _listenforconnections() throws Exception{
ResumableSub_ListenForConnections rsub = new ResumableSub_ListenForConnections(this);
rsub.resume(ba, null);
}
public static class ResumableSub_ListenForConnections extends BA.ResumableSub {
public ResumableSub_ListenForConnections(b4j.example.socket parent) {
this.parent = parent;
}
b4j.example.socket parent;
boolean _successful = false;
anywheresoftware.b4a.objects.SocketWrapper _newsocket = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 26;BA.debugLine="Do While working";
if (true) break;

case 1:
//do while
this.state = 8;
while (parent._working) {
this.state = 3;
if (true) break;
}
if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 27;BA.debugLine="server.Listen";
parent._server.Listen();
 //BA.debugLineNum = 28;BA.debugLine="Wait For Server_NewConnection (Successful As Boo";
parent.__c.WaitFor("server_newconnection", ba, this, null);
this.state = 9;
return;
case 9:
//C
this.state = 4;
_successful = (boolean) result[0];
_newsocket = (anywheresoftware.b4a.objects.SocketWrapper) result[1];
;
 //BA.debugLineNum = 29;BA.debugLine="If Successful Then";
if (true) break;

case 4:
//if
this.state = 7;
if (_successful) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 30;BA.debugLine="CloseExistingConnection		'先關閉 astream/client.避免";
parent._closeexistingconnection();
 //BA.debugLineNum = 31;BA.debugLine="client = NewSocket";
parent._client = _newsocket;
 //BA.debugLineNum = 34;BA.debugLine="astream.InitializePrefix(client.InputStream, Fa";
parent._astream.InitializePrefix(ba,parent._client.getInputStream(),parent.__c.False,parent._client.getOutputStream(),"astream");
 //BA.debugLineNum = 35;BA.debugLine="UpdateState(True)		'成功的話.UI介面 更新狀態";
parent._updatestate(parent.__c.True);
 if (true) break;

case 7:
//C
this.state = 1;
;
 if (true) break;

case 8:
//C
this.state = -1;
;
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _server_newconnection(boolean _successful,anywheresoftware.b4a.objects.SocketWrapper _newsocket) throws Exception{
}
public String  _updatestate(boolean _newstate) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub UpdateState (NewState As Boolean)";
 //BA.debugLineNum = 50;BA.debugLine="connected = NewState";
_connected = _newstate;
 //BA.debugLineNum = 51;BA.debugLine="CallSub(Main, \"SetState\")";
__c.CallSubNew(ba,(Object)(_main.getObject()),"SetState");
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
